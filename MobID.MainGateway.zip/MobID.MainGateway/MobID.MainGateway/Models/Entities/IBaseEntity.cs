﻿namespace MobID.MainGateway.Models.Entities
{
    public interface IBaseEntity
    {
        Guid Id { get; }
    }
}
