﻿namespace MobID.MainGateway.Models.Enums;

public enum OrganizationUserRole
{
    Owner,
    Admin,
    Member
}
