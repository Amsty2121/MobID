﻿namespace MobID.MainGateway.Models.Enums;

public enum AccessNumberScanMode
{
    SingleScan = 0,
    MultiScan = 1
}
