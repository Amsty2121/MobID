﻿namespace MobID.MainGateway.Models.Enums;

public enum QrCodeType
{
    Invite = 0,
    Access = 1
}