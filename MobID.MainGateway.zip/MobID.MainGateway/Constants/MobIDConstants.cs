﻿namespace MobID.MainGateway.Constants
{
    public static class MobIDConstants
    {
        public static string MainDb = "MainDb";
        public static string AuthOptions = "AuthOptions";
    }
}
