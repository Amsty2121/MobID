﻿namespace SmartPass.Repository.Models.Enums
{
    public enum InOutFlag
    {
        None,
        In,
        Out
    }
}
