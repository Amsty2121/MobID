﻿namespace SmartPass.Repository.Models.Enums
{
    public enum SessionStatus
    {
        None,
        Succeeded,
        Failed
    }
}
