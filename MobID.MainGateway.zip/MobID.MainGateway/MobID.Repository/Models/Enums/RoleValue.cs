﻿namespace SmartPass.Repository.Models.Enums
{
    public enum RoleValue
    {
        None,
        PhoneUser,
        Admin,
        Supervizer
    }
}
