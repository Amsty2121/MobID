﻿namespace SmartPass.Repository.Models.Enums
{
    public enum CardState
    {
        None,
        Blocked,
        NotAssigned,
        Active
    }
}
