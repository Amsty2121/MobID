﻿namespace SmartPass.Repository.Models.Enums
{
    public enum CardType
    {
        None,
        Fizic,
        Digital
    }
}
