// src/components/User/User.jsx
import React from "react";
import UserTable from "./Table/UserTable";
import styles from "./User.module.css";

export default function User() {
  return (
    <div className={styles.userPage}>
      <div className={styles["role-page"]}></div>
      <UserTable />
    </div>
  );
}