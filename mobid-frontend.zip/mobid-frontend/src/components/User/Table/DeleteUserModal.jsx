// src/components/User/Table/DeleteUserModal.jsx
import React from "react";
import { FaTimes } from "react-icons/fa";
import styles from "./DeleteUserModal.module.css";

const DeleteUserModal = ({ user, onConfirm, onCancel }) => {
  return (
    <div className={styles.overlay}>
      <div className={styles.content}>
        <button className={styles.closeBtn} onClick={onCancel}>
          <FaTimes />
        </button>
        <h3 className={styles.title}>Confirmă Ștergerea</h3>
        <p className={styles.message}>
          Ești sigur că vrei să ștergi utilizatorul{" "}
          <strong>{user?.username}</strong>?
        </p>
        <div className={styles.actions}>
          <button className={styles.deleteBtn} onClick={onConfirm}>
            Șterge
          </button>
          <button className={styles.cancelBtn} onClick={onCancel}>
            Anulează
          </button>
        </div>
      </div>
    </div>
  );
};

export default DeleteUserModal;
