// src/components/User/Table/AddUserModal.jsx
import React, { useState } from "react";
import { FaTimes } from "react-icons/fa";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
import { createUser } from "../../../api/userApi";
import styles from "./AddUserModal.module.css";

const AddUserModal = ({ onSuccess, onClose }) => {
  const [email, setEmail]       = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError]       = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    try {
      await createUser({ email, username, password });
      onSuccess();
      onClose();
    } catch {
      setError("Nu am putut adăuga utilizatorul.");
    }
  };

  return (
    <div className={styles.addUserModalOverlay}>
      <div className={styles.addUserModalContent}>
        <button className={styles.closeBtn} onClick={onClose}>
          <FaTimes />
        </button>
        <h3 className={styles.title}>Adaugă Utilizator Nou</h3>
        {error && <p className={styles.error}>{error}</p>}
        <form onSubmit={handleSubmit} className={styles.form}>
          <TextField
            label="Email"
            type="email"
            value={email}
            onChange={e => setEmail(e.target.value)}
            required
            variant="outlined"
          />
          <TextField
            label="Username"
            value={username}
            onChange={e => setUsername(e.target.value)}
            required
            variant="outlined"
          />
          <TextField
            label="Parolă"
            type="password"
            value={password}
            onChange={e => setPassword(e.target.value)}
            required
            variant="outlined"
          />

          <div className={styles.actions}>
            <Button type="submit" variant="contained" fullWidth>
              Salvează
            </Button>
            <Button variant="outlined" fullWidth onClick={onClose}>
              Anulează
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddUserModal;
