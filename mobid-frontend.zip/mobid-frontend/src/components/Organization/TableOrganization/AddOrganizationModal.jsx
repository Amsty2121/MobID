// src/components/Organization/TableOrganization/AddOrganizationModal.jsx
import React, { useState, useRef } from "react";
import {
  TextField,
  Autocomplete,
  CircularProgress
} from "@mui/material";
import { getUsersPaged } from "../../../api/userApi";
import { createOrganization } from "../../../api/organizationApi";
import styles from "./AddOrganizationModal.module.css";

export default function AddOrganizationModal({ onSuccess, onClose }) {
  const [name, setName] = useState("");
  const [open, setOpen] = useState(false);
  const [options, setOptions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [selected, setSelected] = useState(null);
  const [error, setError] = useState("");
  const loadedRef = useRef(false);

  const handleOpen = () => {
    setOpen(true);
    if (loadedRef.current) return;
    loadedRef.current = true;
    setLoading(true);
    getUsersPaged({ pageIndex: 0, pageSize: 1000 })
      .then(res => setOptions(res.items || []))
      .catch(() => setError("Nu am putut încărca utilizatorii."))
      .finally(() => setLoading(false));
  };

  const handleClose = () => {
    setOpen(false);
    setError("");
  };

  const handleSubmit = async e => {
    e.preventDefault();
    setError("");
    if (!name.trim()) {
      setError("Introdu un nume pentru organizație.");
      return;
    }
    if (!selected) {
      setError("Selectează un proprietar.");
      return;
    }
    try {
      await createOrganization({
        name,
        ownerId: selected.id
      });
      onSuccess();
      onClose();
    } catch (err) {
      setError("Nu am putut crea organizația: " + err.message);
    }
  };

  return (
    <div className={styles.overlay}>
      <div className={styles.content}>
        <button className={styles.closeBtn} onClick={onClose}>×</button>
        <h3 className={styles.title}>Adaugă Organizație Nouă</h3>

        {error && <p className={styles.error}>{error}</p>}

        <form onSubmit={handleSubmit} className={styles.form}>
          <TextField
            id="orgName"
            label="Nume Organizație"
            variant="outlined"
            value={name}
            onChange={e => setName(e.target.value)}
            fullWidth
            required
          />

          <Autocomplete
            open={open}
            onOpen={handleOpen}
            onClose={handleClose}
            isOptionEqualToValue={(opt, val) => opt.id === val.id}
            options={options}
            loading={loading}
            value={selected}
            onChange={(_, newVal) => setSelected(newVal)}
            getOptionLabel={option => option.username}             // afișează doar numele în input
            renderOption={(props, option) => (                    // cum arată fiecare element din listă
              <li {...props}>
                <div><strong>Name:</strong> {option.username}</div>
                <div><strong>Id:</strong> {option.id}</div>
              </li>
            )}
            filterOptions={(opts, { inputValue }) =>
              opts.filter(o =>
                o.username.toLowerCase().includes(inputValue.trim().toLowerCase()) ||
                o.id.includes(inputValue.trim())
              )
            }
            renderInput={params => (
              <TextField
                {...params}
                label="Proprietar"
                variant="outlined"
                fullWidth
                InputProps={{
                  ...params.InputProps,
                  endAdornment: (
                    <>
                      {loading ? <CircularProgress size={20} /> : null}
                      {params.InputProps.endAdornment}
                    </>
                  )
                }}
              />
            )}
          />

          <div className={styles.actions}>
            <button type="submit" className={styles.primaryBtn}>
              Salvează
            </button>
            <button
              type="button"
              className={styles.outlinedBtn}
              onClick={onClose}
            >
              Anulează
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
