// src/components/Organization/TableOrganization/DeleteOrganizationModal.jsx
import React from "react";
import { FaTimes } from "react-icons/fa";
import styles from "./DeleteOrganizationModal.module.css";

const DeleteOrganizationModal = ({ organization, onConfirm, onCancel }) => {
  return (
    <div className={styles.overlay}>
      <div className={styles.content}>
        <button className={styles.closeBtn} onClick={onCancel}>
          <FaTimes />
        </button>
        <h3 className={styles.title}>Confirmă Ștergerea</h3>
        <p className={styles.message}>
          Ești sigur că vrei să ștergi organizația{" "}
          <strong>{organization?.name}</strong>?
        </p>
        <div className={styles.actions}>
          <button
            type="button"
            className={styles.primaryBtn}
            onClick={onConfirm}
          >
            Șterge
          </button>
          <button
            type="button"
            className={styles.outlinedBtn}
            onClick={onCancel}
          >
            Anulează
          </button>
        </div>
      </div>
    </div>
  );
};

export default DeleteOrganizationModal;
