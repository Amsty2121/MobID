// src/components/Organization/TableOrganization/EditOrganizationModal.jsx
import React, { useState, useEffect, useRef } from "react";
import { FaTimes } from "react-icons/fa";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
import Select from "react-select";
import { getUsersForOrganization } from "../../../api/organizationApi";
import styles from "./EditOrganizationModal.module.css";

export default function EditOrganizationModal({ organization, onSubmit, onClose }) {
  const [newName, setNewName]        = useState("");
  const [members, setMembers]        = useState([]);
  const [selectedOwner, setSelected] = useState(null);
  const [loading, setLoading]        = useState(true);
  const [error, setError]            = useState("");
  const didFetch = useRef(false);

  useEffect(() => {
    setNewName(organization.name);
    setError("");
    setSelected({
      value: organization.ownerId,
      label: organization.ownerName
    });

    if (didFetch.current) return;
    didFetch.current = true;

    (async () => {
      try {
        const opts = await getUsersForOrganization(organization.id);
        setMembers(opts.map(m => ({
          value: m.userId,
          label: m.userName
        })));
      } catch {
        setError("Nu am putut încărca membrii.");
      } finally {
        setLoading(false);
      }
    })();
  }, [organization]);

  const handleSubmit = async e => {
    e.preventDefault();
    if (!selectedOwner) {
      setError("Trebuie să selectezi un proprietar.");
      return;
    }
    setError("");
    await onSubmit({
      organizationId: organization.id,
      name:           newName.trim() || null,
      ownerId:        selectedOwner.value
    });
    onClose();
  };

  return (
    <div className={styles.overlay}>
      <div className={styles.content}>
        <button className={styles.closeBtn} onClick={onClose}>
          <FaTimes />
        </button>
        <h3 className={styles.title}>Actualizează Organizația</h3>
        {error && <p className={styles.error}>{error}</p>}
        <form onSubmit={handleSubmit} className={styles.form}>
          <TextField
            label="Nume Organizație"
            value={newName}
            onChange={e => setNewName(e.target.value)}
            required
            variant="outlined"
            fullWidth
          />
          <Select
            options={members}
            isLoading={loading}
            value={selectedOwner}
            onChange={setSelected}
            placeholder="Alege proprietar..."
            noOptionsMessage={() => "Niciun membru găsit"}
            classNamePrefix="org-select"
          />
          <div className={styles.actions}>
            <Button type="submit" variant="contained" fullWidth>
              Salvează
            </Button>
            <Button variant="outlined" fullWidth onClick={onClose}>
              Anulează
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
