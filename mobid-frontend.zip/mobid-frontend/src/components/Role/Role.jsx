// src/components/Role/Role.jsx
import React from "react";
import styles from "./Role.module.css";
import RoleTable from "./Table/RoleTable";

export default function Role() {
  return (
    <div className={styles.rolePage}>
      <RoleTable />
    </div>
  );
}
