// src/components/Role/Table/DeleteRoleModal.jsx
import React from "react";
import { FaTimes } from "react-icons/fa";
import styles from "./DeleteRoleModal.module.css";

const DeleteRoleModal = ({ role, onConfirm, onCancel }) => {
  return (
    <div className={styles.overlay}>
      <div className={styles.content}>
        <button className={styles.closeBtn} onClick={onCancel}>
          <FaTimes />
        </button>
        <h3 className={styles.title}>Confirmă Ștergerea</h3>
        <p className={styles.message}>
          Ești sigur că vrei să ștergi rolul{" "}
          <strong>{role?.name}</strong>?
        </p>
        <div className={styles.actions}>
          <button
            type="button"
            className={styles.deleteBtn}
            onClick={onConfirm}
          >
            Șterge
          </button>
          <button
            type="button"
            className={styles.cancelBtn}
            onClick={onCancel}
          >
            Anulează
          </button>
        </div>
      </div>
    </div>
  );
};

export default DeleteRoleModal;
