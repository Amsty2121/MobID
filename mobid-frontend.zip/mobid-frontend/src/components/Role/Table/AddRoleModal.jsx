// src/components/Role/Table/AddRoleModal.jsx
import React, { useState } from "react";
import { FaTimes } from "react-icons/fa";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
import { addRole } from "../../../api/roleApi";
import styles from "./AddRoleModal.module.css";

export default function AddRoleModal({ onSuccess, onClose }) {
  const [name, setName]             = useState("");
  const [description, setDescription] = useState("");
  const [error, setError]           = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    try {
      await addRole(name, description);
      onSuccess();
      onClose();
    } catch {
      setError("Nu am putut adăuga rolul.");
    }
  };

  return (
    <div className={styles.addRoleModalOverlay}>
      <div className={styles.addRoleModalContent}>
        <button className={styles.closeBtn} onClick={onClose}>
          <FaTimes />
        </button>

        <h3 className={styles.title}>Adaugă Rol Nou</h3>

        {error && <div className={styles.error}>{error}</div>}

        <form onSubmit={handleSubmit} className={styles.form}>
          <TextField
            label="Nume Rol *"
            variant="outlined"
            value={name}
            onChange={e => setName(e.target.value)}
            required
            fullWidth
          />

          <TextField
            label="Descriere"
            variant="outlined"
            value={description}
            onChange={e => setDescription(e.target.value)}
            fullWidth
          />

          <div className={styles.actions}>
            <Button variant="contained" type="submit" fullWidth>
              Salvează
            </Button>

            <Button variant="outlined" onClick={onClose} fullWidth>
              Anulează
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
